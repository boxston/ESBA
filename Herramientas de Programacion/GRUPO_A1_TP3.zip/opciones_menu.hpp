#ifndef MENUOPCIONES_H
#define MENUOPCIONES_H

#include <string>

using namespace std;
const int cantidad = 10;
const string opciones[cantidad] = {
    "TP 2 - Ej 1",
    "TP 2 - Ej 2",
    "TP 2 - Ej 3",
    "TP 2 - Ej 4",
    "TP 3 - Ej 1",
    "TP 3 - Ej 2",
    "TP 3 - Ej 3",
    "TP 3 - Ej 4",
    "Integrantes del Grupo",
    "Salir ..."
};
#endif
