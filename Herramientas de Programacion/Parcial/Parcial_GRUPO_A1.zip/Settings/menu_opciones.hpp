#ifndef MENUOPCIONES_H
#define MENUOPCIONES_H

#include <string>

using namespace std;
const int cantidad = 5;
const string opciones[cantidad] = {
    "Programa 1",
    "Programa 2",
    "Programa 2 - GRAFICO",
    "Integrantes del Grupo",
    "Salir ..."
};
#endif

