#ifndef MENUOPCIONES_H
#define MENUOPCIONES_H

#include <string>

using namespace std;
const int cantidad = 7;
const string opciones[cantidad] = {
    "TP 1",
    "TP 2 - Ej 1",
    "TP 2 - Ej 2",
    "TP 2 - Ej 3",
    "TP 2 - Ej 4",
    "Integrantes del Grupo",
    "Salir ..."
};
#endif
